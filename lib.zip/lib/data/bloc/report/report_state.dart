part of 'report_bloc.dart';

abstract class ReportState extends Equatable {
  const ReportState();

  @override
  List<Object?> get props => [];
}

class ReportInitial extends ReportState {}

class ReportDetail extends ReportState {
  final String reportType;

  const ReportDetail(this.reportType);

  @override
  List<Object?> get props => [reportType];
}
